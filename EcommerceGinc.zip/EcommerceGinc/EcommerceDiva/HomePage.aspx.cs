﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EcommerceDiva
{
    public partial class HomePage : System.Web.UI.Page
    {
        public static String cs = ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
           //BindCartNumber22();
            if (Session["Username"] != null)
            {
                btnlogout.Visible = true;
                btnLogin.Visible = false;
                lblSuccess.Text = " Welcome <b>" + Session["Username"].ToString() + " on Divana Ecom"+ "</b>";
                USNAME.Text = "Welcome: " + Session["Username"].ToString().ToUpper();
            }
            else
            {
                btnlogout.Visible = false;
                btnLogin.Visible = true;
                Response.Redirect("Login.aspx");
            }
        }
        protected void Btnlogout_Click(object sender, EventArgs e)
        {
            //Session.Abandon();
            Session["Username"] = null;
            Response.Redirect("~/Default.aspx");

        }

        protected void BtnLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Login.aspx");
        }
       // public void BindCartNumber()
       // {
         //   if (Request.Cookies["CartPID"] != null)
          //  {
            //    string CookiePID = Request.Cookies["CartPID"].Value.Split('=')[1];
             //   string[] ProductArray = CookiePID.Split(',');
               // int ProductCount = ProductArray.Length;
               // pCount.InnerText = ProductCount.ToString();
           // }
          //  else
          //  {
           //     pCount.InnerText = 0.ToString();
          //  }
      //  }

     
        }
    }
