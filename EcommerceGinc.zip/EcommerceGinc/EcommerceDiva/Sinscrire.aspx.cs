﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EcommerceDiva
{
    public partial class Sinscrire : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtSinscrire_Click(object sender, EventArgs e)
        {

            if (Is_FormValid())
            {
                  using (SqlConnection con = new SqlConnection(ConfigurationManager .ConnectionStrings["DivanaDB"].ConnectionString))
                {
                    con.Open();
                    //insertion a la bd
                    SqlCommand cmd = new SqlCommand("INSERT INTO T_Users (Username, Password, Email,Name,Usertype) VALUES('" + txtUsername.Text + "','" + txtPass.Text + "','" + txtEmail.Text + "','" + txtName.Text + "' ,'User' )", con);
                    cmd.ExecuteNonQuery();
                  //  Response.Write("<script> alert('Inscription réussie'); </script>");
                    effacer();
                    con.Close();
                    //Message si l inscription reussie
                    //MsgLbl.Text = "Inscription réussie";
                    MsgLbl.ForeColor = System.Drawing.Color.Gray;
                }
                Response.Redirect("~/Login.aspx");
            }
            else
            {
               // Response.Write("<script> alert('Echec'); </script>");
                MsgLbl.Text = "Veuillez remplir tous les champs";
                MsgLbl.ForeColor = System.Drawing.Color.Red;
            }
           
        }

        private bool Is_FormValid()
        {
           if (txtUsername.Text == "")
            {
                MsgLbl.Text = "Username incorrect";
                MsgLbl.ForeColor = System.Drawing.Color.Red;
                //Response.Write("<script> alert('Username incorrect'); </script>");
                txtUsername.Focus();
                return false;
            }
            else if (txtPass.Text =="")
            {
                MsgLbl.Text = "Username incorrect";
                MsgLbl.ForeColor = System.Drawing.Color.Red;
              //  Response.Write("<script> alert('Password incorrect'); </script>");
                txtPass.Focus();
                return false;
            }
            else if(txtPass .Text != txtCPass.Text)
            {
                MsgLbl.Text = "Password incorrect";
                MsgLbl.ForeColor = System.Drawing.Color.Red;
                //Response.Write("<script> alert('Password incorrect'); </script>");
                txtCPass.Focus();
                return false;
            }
            else if (txtEmail.Text=="")
            {
                MsgLbl.Text = "Email incorrect";
                MsgLbl.ForeColor = System.Drawing.Color.Red;
                //Response.Write("<script> alert('Email incorrect'); </script>");
                return false;
            }
            else if (txtName.Text == "")
            {
                MsgLbl.Text = "Name incorrect";
                MsgLbl.ForeColor = System.Drawing.Color.Red;
               // Response.Write("<script> alert('Name incorrect'); </script>");
                return false;
            }
            return true;
        }
        private void effacer()
        {
            txtName.Text = string.Empty;
            txtPass.Text = string.Empty;
            txtUsername.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtCPass.Text = string.Empty;
        }
    }
}