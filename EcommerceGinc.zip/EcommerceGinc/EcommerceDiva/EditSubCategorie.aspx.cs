﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EcommerceDiva
{
    public partial class EditSubCategorie : System.Web.UI.Page
    {
        new string ID = "";
        string SCName = "";
        string CID = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null)
            {
                if (!IsPostBack)
                {
                    BindGridview();
                }
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        //==========================================================
        protected void txtID_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString);
            if (con.State == ConnectionState.Closed) { con.Open(); }
            SqlCommand cmd = new SqlCommand("SELECT SubCatID,SubCatName,CatID FROM T_SubCategory WHERE SubCatID=@ID", con);
            cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(txtID.Text));
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds, "dt");
            con.Close();

            if (ds.Tables[0].Rows.Count > 0)
            {

                ID = ds.Tables[0].Rows[0]["SubCatID"].ToString();
                SCName = ds.Tables[0].Rows[0]["SubCatName"].ToString();
                CID = ds.Tables[0].Rows[0]["CatID"].ToString();
                BindMainCat();
                txtSubCategory.Text = SCName;

            }
            else
            {
                ID = "";
                SCName = "";
                CID = "";
            }
            con.Close();
        }

        private void BindGridview()
        {

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString);
            if (con.State == ConnectionState.Closed) { con.Open(); }
            SqlDataAdapter da = new SqlDataAdapter("SELECT t1.SubCatID AS ID,t2.CatName AS Category,t1.SubCatName AS SubCategory FROM T_SubCategory AS t1 INNER JOIN T_Category AS t2 on t2.CatID=t1.CatID", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }

            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }
        }

        private void BindMainCat()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                if (con.State == ConnectionState.Closed) { con.Open(); }
                SqlCommand cmd = new SqlCommand("SELECT * FROM  T_Category", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                con.Close();
                if (dt.Rows.Count != 0)
                {
                    ddlMainCategory.DataSource = dt;
                    ddlMainCategory.DataTextField = "CatName";
                    ddlMainCategory.DataValueField = "CatID";
                    ddlMainCategory.DataBind();
                    ddlMainCategory.Items.Insert(0, new ListItem("-Select-", "0"));
                    ddlMainCategory.SelectedValue = CID;

                }
            }
        }
        //================================================================
        protected void btnUpdateSubCategory_Click(object sender, EventArgs e)
        {

            if (txtID.Text != string.Empty && txtSubCategory.Text != string.Empty && ddlMainCategory.SelectedIndex != -1)
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString);
                if (con.State == ConnectionState.Closed) { con.Open(); }
                SqlCommand cmd = new SqlCommand("UPDATE T_SubCategory SET SubCatName=@SCN , CatID=@MCI WHERE SubCatID=@ID", con);
                cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(txtID.Text));
                cmd.Parameters.AddWithValue("@MCI", ddlMainCategory.SelectedValue);
                cmd.Parameters.AddWithValue("@SCN", txtSubCategory.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Update successfully')</script>");
                BindGridview();
                txtID.Text = string.Empty;
                ddlMainCategory.SelectedIndex = -1;
                txtSubCategory.Text = string.Empty;
            }


        }
    }
}