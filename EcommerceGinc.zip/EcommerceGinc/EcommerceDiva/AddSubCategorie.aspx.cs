﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace EcommerceDiva
{
    public partial class AddSubCategorie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)

        {

            if (!IsPostBack)
            {
                BindMainCategory();
                BindSubCatRptr();
            }
        }


        //********************************************************************************************
        private void BindSubCatRptr()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT A.*,B.* FROM T_SubCategory A INNER JOIN T_Category B on B.CatID  =A.CatID  ", con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        rptrSubCat.DataSource = dt;
                        rptrSubCat.DataBind();
                    }
                }
            }
        }
        //*********************************************************************************************
        protected void BtnAddSubCategory_Click(object sender, EventArgs e)
        {
            if (txtSubCategory.Text != null && txtSubCategory.Text != "" && txtSubCategory.Text != string.Empty)
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO T_SubCategory(SubCatName, CatID) VALUES('" + txtSubCategory.Text + "' , '"+ addlMainCatID.SelectedItem.Value   +"')", con);
                    cmd.ExecuteNonQuery();
                    MsgLbl.Text = "Sous Catégorie Added Successfully";
                    MsgLbl.ForeColor = System.Drawing.Color.Green;
                    //Response.Write("<script> alert('Brand Added Successfully ');  </script>");
                    txtSubCategory.Text = string.Empty;
                    con.Close();
                    addlMainCatID.ClearSelection();
                    addlMainCatID.Items.FindByValue("0").Selected = true;
                    //txtSubCategory.Focus();


                }
            }
            BindSubCatRptr();
        }
        //selection dans Categorie
        private void BindMainCategory()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM T_Category", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    addlMainCatID.DataSource = dt;
                    addlMainCatID.DataTextField = "CatName";
                    addlMainCatID.DataValueField = "CatID";
                    addlMainCatID.DataBind();
                    addlMainCatID.Items.Insert(0, new ListItem("-Select-", "0"));

                }




            }
        }
    }
}