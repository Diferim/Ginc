﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace EcommerceDiva
{
    public partial class PasswordReset : System.Web.UI.Page
    {
        String GUIDvalue;

        int IdUser;
        DataTable dt = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {


            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                //con.Open();
                GUIDvalue = Request.QueryString["Id"];

                if (GUIDvalue != null)
                {
                    SqlCommand cmd = new SqlCommand("SELECT * FROM T_ForgotPwd WHERE Id=@Id", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@Id", GUIDvalue);
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);

                    sda.Fill(dt);
                    if (dt.Rows.Count != 0)
                    {
                        IdUser = Convert.ToInt32(dt.Rows[0][1]);
                    }
                    else
                    {
                        lblmsg.Text = "Your Password Reset Link is Expired or Invalid...try again";
                        lblmsg.ForeColor = System.Drawing.Color.Red;
                    }

                }
                else
                {
                    Response.Redirect("~/Default.aspx");
                }

            }

            if (!IsPostBack)
            {
                if (dt.Rows.Count != 0)
                {
                    txtConfirmPass.Visible = true;
                    txtNewPass.Visible = true;
                    lblNewPassword.Visible = true;
                    lblConfirmPass.Visible = true;
                    btnResetPass.Visible = true;
                }
                else
                {
                    lblmsg.Text = "Your Password Reset Link is Expired or Invalid...try again";
                    lblmsg.ForeColor = System.Drawing.Color.Red;

                }

            }


        }

        protected void btnResetPass_Click(object sender, EventArgs e)
        {
            if (txtNewPass.Text != "" && txtConfirmPass.Text != "" && txtNewPass.Text == txtConfirmPass.Text)
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
                {
                    // mise a jour
                    con.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE T_Users set Password=@pwd where IdUser=@IdUser", con);
                    cmd.Parameters.AddWithValue("@pwd", txtNewPass.Text);
                    cmd.Parameters.AddWithValue("@IdUser", IdUser);
                    cmd.ExecuteNonQuery();

                    //suppression de l ancien
                    SqlCommand cmd2 = new SqlCommand("DELETE FROM T_ForgotPwd WHERE IdUser='" + IdUser + "'", con);
                    cmd2.ExecuteNonQuery();
                    Response.Write("<script> alert('Password Reset Successfully done');  </script>");
                    Response.Redirect("~/Login.aspx");
                }
            }
        }
    }
    
}