﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;
using System.Threading;


namespace EcommerceDiva
{
    public partial class Products : System.Web.UI.Page
    {
        public static String CSdb = ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] != null)
            {
                if (!IsPostBack)
                {
                    if (Request.QueryString["BuyNow"] == "YES")
                    {

                    }
                    BindProductRepeater();
                    BindCartNumber();

                }
            }
            else
            {
                if (Request.QueryString["BuyNow"] == "YES")
                {
                    Response.Redirect("Login.aspx");
                }
                else
                {
                    Response.Redirect("~/Default.aspx");
                }
            }
        }

        //************************************************************************************
        private void BindProductRepeater()
        {
            using (SqlConnection con = new SqlConnection(CSdb))
            {
                using (SqlCommand cmd = new SqlCommand("PS_BindAllProducts", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        rptrProducts.DataSource = dt;
                        rptrProducts.DataBind();
                        if (dt.Rows.Count <= 0)
                        {
                            Label1.Text = "Sorry! Currently no products in this category.";
                        }
                        else
                        {
                            Label1.Text = "Showing All Products";
                        }
                    }
                }
            }
        }
        //***********************************************************************************

        //********************************************************************************
        protected override void InitializeCulture()
        {
            CultureInfo ci = new CultureInfo("en-IN");
            ci.NumberFormat.CurrencySymbol = "€";
            Thread.CurrentThread.CurrentCulture = ci;

            base.InitializeCulture();
        }
        //******************************************************************************
        protected void btnCart2_ServerClick(object sender, EventArgs e)
        {
            Response.Redirect("~/Panier.aspx");
        }

        //*************************************************************************************
        public void BindCartNumber()
        {
            if (Session["USERID"] != null)
            {
                string IdUser = Session["USERID"].ToString();
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(CSdb))
                {
                    SqlCommand cmd = new SqlCommand("PS_BindCartNumberz", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.AddWithValue("@IdUser", IdUser);
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            string CartQuantity = dt.Compute("Sum(Qty)", "").ToString();
                            CartBadge.InnerText = CartQuantity;
                        }
                        else
                        {
                            // _ = CartBadge.InnerText == 0.ToString();
                            CartBadge.InnerText = "0";
                        }
                    }
                }
            }
        }
        //******************************************************************************

        protected void txtFilterGrid1Record_TextChanged(object sender, EventArgs e)
        {
            if (txtFilterGrid1Record.Text != string.Empty)
            {
                SqlConnection con = new SqlConnection(CSdb);
                con.Open();
                string LaRequete = "SELECT A.*,B.*,C.Name ,A.ProdPrice-A.ProdSelPrice as DiscAmount,B.Name as ImageName, C.Name as BrandName from T_Products A INNER JOIN T_Brands C on C.BrandID =A.BrandID  CROSS APPLY( SELECT TOP 1 * FROM T_ProductImages B WHERE B.ProdID= A.ProdID ORDER BY B.ProdID DESC )B WHERE  A.PName LIKE '" + txtFilterGrid1Record.Text + "%' ORDER BY A.ProdID DESC";
                SqlDataAdapter da = new SqlDataAdapter(LaRequete, con);
                string text = ((TextBox)sender).Text;
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    rptrProducts.DataSource = ds.Tables[0];
                    rptrProducts.DataBind();
                }
                else
                {

                }
            }
            else
            {
                BindProductRepeater();
            }
        }
     }
}