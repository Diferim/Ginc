﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EcommerceDiva
{
    public partial class AddCategorie : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BindCategoryRptr();
        }

        private void BindCategoryRptr()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM T_Category", con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        rptrCat.DataSource = dt;
                        rptrCat.DataBind();
                    }
                }
            }
        }
        //*********************************************************************************************

        protected void BtnAddtxtCategorie_Click(object sender, EventArgs e)
        {
            if (txtCategory.Text != null && txtCategory.Text != "" && txtCategory.Text != string.Empty)
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO T_Category(CatName) VALUES('" + txtCategory.Text + "')", con);
                    cmd.ExecuteNonQuery();
                    MsgLbl.Text = "Category Added Successfully";
                    MsgLbl.ForeColor = System.Drawing.Color.Green;
                    //Response.Write("<script> alert('Brand Added Successfully ');  </script>");
                    txtCategory.Text = string.Empty;
                    con.Close();

                    txtCategory.Focus();


                }
                BindCategoryRptr();
            }
        }
    }
}