﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;
using System.Threading;

namespace EcommerceDiva
{
    public partial class AddMarque : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BindBrandRptr();
        }
        private void BindBrandRptr()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM T_Brands", con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        RptrBrands.DataSource = dt;
                        RptrBrands.DataBind();
                    }
                }
            }
        }
        //*********************************************************************************************
        protected void BtnAddMarque_Click(object sender, EventArgs e)
        {
            if (txtBrand.Text != null && txtBrand.Text != "" && txtBrand.Text != string.Empty)
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("INSERT INTO T_Brands(Name) VALUES('" + txtBrand.Text + "')", con);
                    cmd.ExecuteNonQuery();
                    MsgLbl.Text = "Brand Added Successfully";
                    MsgLbl.ForeColor = System.Drawing.Color.Green;
                    //Response.Write("<script> alert('Brand Added Successfully ');  </script>");
                    txtBrand.Text = string.Empty;
                    con.Close();
                    
                    txtBrand.Focus();


                }
                BindBrandRptr();
            }
        }
        //************************************************************************************
        protected void RptrBrands_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            Int32 IdUser = Convert.ToInt32(Session["USERID"].ToString()); 
            if (e.CommandName == "RemoveThisBrand")
            {
                int BrandID = Convert.ToInt32(e.CommandArgument.ToString().Trim());
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
                {
                    SqlCommand myCmd = new SqlCommand("PS_DeleteThisBrand", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    myCmd.Parameters.AddWithValue("@BrandID", BrandID);
                    con.Open();
                    myCmd.ExecuteNonQuery();
                    con.Close();
                    BindBrandRptr();
                 
                }
            }
        }
    }
}