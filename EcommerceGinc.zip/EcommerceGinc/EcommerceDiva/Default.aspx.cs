﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;
using System.Threading;

namespace EcommerceDiva
{
    public partial class Default : System.Web.UI.Page
    {
        public static String CSdb = ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            //2- ngrok http https://localhost:44365 -host-header="localhost:44365"
            //1- ngrok authtoken 1t4S68MOSaCRo5tzXk6GLQQZcxX_4BMKPYW4pUDtheFFFpZZW
            
            if (Request.QueryString["UserLogin"] == "VE")
            {

                Response.Redirect("HomePage.aspx?UserLogin=VE");
            }

            if (Request.QueryString["UserLogin"] == "U")
            {
                Response.Redirect("Products.aspx?UserLogin=U");
            }

            else
            {

                if (Session["Username"] != null)
            {
                //lblSuccess.Text = "Login Success, Welcome <b>" + Session["Username"].ToString() + "</b>";

                if (!this.IsPostBack)
                {
                    BindCartNumber();
                    BindProductRepeater();
                    btnInscrire.Visible = false;
                    btnLogin.Visible = false;
                    btnlogout.Visible = true;
                }

            }
            else
            {
                BindProductRepeater();
                btnInscrire.Visible = true;
                btnLogin.Visible = true;
                btnlogout.Visible = false;
               Response.Redirect("Login.aspx");
                    // Response.Write("<script type='text/javascript'>alert('Please you must login')</script>");

                }
            }

        }

        //*****************************************************************************************
        public void BindCartNumber()
        {
            if (Request.Cookies["CartPID"] != null)
            {
                string CookiePID = Request.Cookies["CartPID"].Value.Split('=')[1];
                string[] ProductArray = CookiePID.Split(',');
                int ProductCount = ProductArray.Length;
                pCount.InnerText = ProductCount.ToString();
            }
            else
            {
                pCount.InnerText = 0.ToString();
            }
        }

        //***********************************************************************************************
        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Session["Username"] = null;
            Session.RemoveAll();
            Response.Redirect("Default.aspx");
        }

        //**************************************************************************************************************

        private void BindProductRepeater()
        {
            using (SqlConnection con = new SqlConnection(CSdb))
            {
                using (SqlCommand cmd = new SqlCommand("PS_BindAllProducts", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        rptrProducts.DataSource = dt;
                        rptrProducts.DataBind();
                        if (dt.Rows.Count <= 0)
                        {
                           // Label1.Text = "Sorry! Currently no products in this category.";
                            pCount.InnerHtml = "0";
                        }
                        else
                        {
                            //Label1.Text = "Showing All Products";
                        }
                    }
                }
            }
        }
        //*************************************************************************************************

        protected override void InitializeCulture()
        {
            CultureInfo ci = new CultureInfo("en-IN");
            ci.NumberFormat.CurrencySymbol = "€";
            Thread.CurrentThread.CurrentCulture = ci;

            base.InitializeCulture();
        }
    }
}