﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
 using System.Data.SqlClient;
using System.Configuration;


namespace EcommerceDiva
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // obtient une valeur qui indique si la page est envoyée pour la premiere fois......
            if (!IsPostBack)
            {
                if (Request.Cookies["USNAME"] != null && Request.Cookies["UPWD"] != null)
                {
                    txtUsername.Text = Request.Cookies["USNAME"].Value;
                    txtPass.Text = Request.Cookies["UPWD"].Value;
                    RememberMe.Checked = true;

                }
            }
        }

        protected void  BtnLogin_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                con.Open();
                // requete de selection
                SqlCommand cmd = new SqlCommand("SELECT * FROM  T_Users WHERE Username=@username and Password=@pwrd", con);
                //recuperation des valeurs
                cmd.Parameters.AddWithValue("@username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@pwrd", txtPass.Text);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dtle = new DataTable();
                sda.Fill(dtle);
                if (dtle.Rows.Count != 0)
                {
                    //gestion des session sur le user
                    Session["USERID"] = dtle.Rows[0]["IdUser"].ToString();
                    Session["USEREMAIL"] = dtle.Rows[0]["Email"].ToString();
                    Response.Cookies["USNAME"].Expires = DateTime.Now.AddDays(-1);
                    Response.Cookies["UPWD"].Expires = DateTime.Now.AddDays(-1);

                    if (RememberMe.Checked)
                    {
                        //gestion des cookies sur le user
                        Response.Cookies["USNAME"].Value = txtUsername.Text;
                        Response.Cookies["UPWD"].Value = txtPass.Text;
                        //ouverture
                        Response.Cookies["USNAME"].Expires = DateTime.Now.AddDays(10);
                        Response.Cookies["UPWD"].Expires = DateTime.Now.AddDays(10);

                    }
                    else
                    {
                        //fermeture
                        Response.Cookies["USNAME"].Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies["UPWD"].Expires = DateTime.Now.AddDays(-1);
                    }

                    string USTYPE;
                    // Trim supprime les espaces blancs
                    USTYPE = dtle.Rows[0][5].ToString().Trim();

                    if (USTYPE == "User")
                    {
                        Session["Username"] = txtUsername.Text;
                        Session["USEREMAIL"] = dtle.Rows[0]["Email"].ToString();
                        Session["getFullName"] = dtle.Rows[0]["name"].ToString();
                       
                        Session["LoginType"] = "User";
                        if (Request.QueryString["rurl"] != null)
                        {
                            if (Request.QueryString["rurl"] == "cart")
                            {
                                Response.Redirect("Panier.aspx");
                            }

                            if (Request.QueryString["rurl"] == "PID")
                            {
                                string myPID = Session["ReturnPID"].ToString();
                                Response.Redirect("ProductView.aspx?PID=" + myPID + "");
                            }
                        }

                        else
                        {
                            
                            Response.Redirect("Default.aspx?UserLogin=U");
                           // Response.Redirect("HomePage.aspx?UserLogin=YES");
                        }



                    }
                    //******************************************************************************************************
                    if (USTYPE == "Vendor")
                    {
                        Session["Username"] = txtUsername.Text;
                        Session["USEREMAIL"] = dtle.Rows[0]["Email"].ToString();
                        Session["getFullName"] = dtle.Rows[0]["name"].ToString();
                      
                        Session["LoginType"] = "Vendor";
                        if (Request.QueryString["rurl"] != null)
                        {
                            if (Request.QueryString["rurl"] == "cart")
                            {
                                Response.Redirect("Panier.aspx");
                            }

                            if (Request.QueryString["rurl"] == "PID")
                            {
                                string myPID = Session["ReturnPID"].ToString();
                                Response.Redirect("ProductView.aspx?PID=" + myPID + "");
                            }
                        }

                        else
                        {

                            Response.Redirect("Default.aspx?UserLogin=VE");
                            // Response.Redirect("HomePage.aspx?UserLogin=YES");
                        }



                    }
                    //********************************************************************************
                    if (USTYPE == "Admin")
                    {
                        Session["Username"] = txtUsername.Text;
                        Session["LoginType"] = "Admin";
                        Response.Redirect("~/AdminHome.aspx");
                    }
                }
                else
                {
                    lblError.Text = "Invalid Username or password";
                }
                clr();
                con.Close();
            }
        }

        private void clr()
        {
            txtPass.Text = string.Empty;
            txtUsername.Text = string.Empty;
            txtUsername.Focus();

        }
    }
    
}