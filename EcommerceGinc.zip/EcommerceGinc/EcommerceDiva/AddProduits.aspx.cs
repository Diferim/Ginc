﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;



namespace EcommerceDiva
{
    public partial class AddProduits : System.Web.UI.Page
    {
        // CSdb de la connexion a la base de données
        public static String CSdb = ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //when page first time run then this code will execute
                BindBrand();
                BindCategory();
                BindGender();
                addlSubCategory.Enabled = false;
                addlGender.Enabled = false;
                BindGridview1();

            }
        }

        private void BindGridview1()
        {
            SqlConnection con = new SqlConnection(CSdb);
            //string LaRequete = " SELECT DISTINCT t1.ProdID,t1.PName,t1.ProdPrice,t1.ProdSelPrice,t2.Name AS Brand,t3.CatName,t4.SubCatName, t5.GenderName AS Gender,t6.SizeName,t8.Quantity FROM T_Products AS t1  INNER JOIN T_Brands AS t2 on t2.BrandID=t1.BrandID  INNER JOIN T_Category AS t3 ON t3.CatID=t1.CatID  INNER JOIN T_SubCategory AS t4 ON t4.SubCatID=t1.SubCatID  INNER JOIN T_Gender AS t5 ON t5.GenderID =t1.GenderID  INNER JOIN T_Sizes AS t6 ON t6.SubCatID=t1.SubCatID  INNER JOIN T_ProductSizeQuantity AS t8 ON t8.PID=t1.ProdID ORDER BY t1.PName";
            SqlCommand cmd = new SqlCommand("PS_ShowAllProducts", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                GridView1.DataSource = dt;
                GridView1.DataBind();
            }
            else
            {
                GridView1.DataSource = null;
                GridView1.DataBind();
            }

        }


        //*********************************************************************************************
        private void BindGender()
        {
            using (SqlConnection con = new SqlConnection(CSdb))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM T_Gender WITH(nolock)", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    addlGender.DataSource = dt;
                    addlGender.DataTextField = "GenderName";
                    addlGender.DataValueField = "GenderID";
                    addlGender.DataBind();
                    addlGender.Items.Insert(0, new ListItem("-Select-", "0"));

                }
            }
        }
        //******************************************************************************************************
        private void BindBrand()
        {
            using (SqlConnection con = new SqlConnection(CSdb))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM T_Brands ", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    addlBrand.DataSource = dt;
                    addlBrand.DataTextField = "Name";
                    addlBrand.DataValueField = "BrandID";
                    addlBrand.DataBind();
                    addlBrand.Items.Insert(0, new ListItem("-Select-", "0"));

                }
            }
        }
        //*********************************************************************************************
        private void BindCategory()
        {
            using (SqlConnection con = new SqlConnection(CSdb))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM T_Category", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    addlCategory.DataSource = dt;
                    addlCategory.DataTextField = "CatName";
                    addlCategory.DataValueField = "CatID";
                    addlCategory.DataBind();
                    addlCategory.Items.Insert(0, new ListItem("-Select-", "0"));

                }
            }
        }
        //***********************************************************************************
        protected void BtnAdd_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(CSdb))
            {
                // utilisation déune procedure stockée
                SqlCommand cmd = new SqlCommand("PS_InsertProducts", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@PName", txtProductName.Text);
                cmd.Parameters.AddWithValue("@ProdPrice", txtPrice.Text);
                cmd.Parameters.AddWithValue("@ProdSelPrice", txtselPrice.Text);
                cmd.Parameters.AddWithValue("@ProdDescription", txtDescription.Text);
                cmd.Parameters.AddWithValue("@ProdProductDetails", txtPDetail.Text);
                cmd.Parameters.AddWithValue("@ProdMaterialCare", txtMatCare.Text);
                if (chFD.Checked == true)
                {
                    cmd.Parameters.AddWithValue("@FreeDelivery", 1.ToString());
                }
                else
                {
                    cmd.Parameters.AddWithValue("@FreeDelivery", 0.ToString());
                }

                if (ch30Ret.Checked == true)
                {
                    cmd.Parameters.AddWithValue("@30DayRet", 1.ToString());
                }
                else
                {
                    cmd.Parameters.AddWithValue("@30DayRet", 0.ToString());
                }
                if (cbCOD.Checked == true)
                {
                    cmd.Parameters.AddWithValue("@COD", 1.ToString());
                }
                else
                {
                    cmd.Parameters.AddWithValue("@COD", 0.ToString());
                }
                cmd.Parameters.AddWithValue("@BrandID", addlBrand.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@CatID", addlCategory.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@SubCatID", addlSubCategory.SelectedItem.Value);
                cmd.Parameters.AddWithValue("@GenderID", addlGender.SelectedItem.Value);
                con.Open();
                Int64 ProdID = Convert.ToInt64(cmd.ExecuteScalar());
     
                //Insert size quantity
                for (int i = 0; i < cblSize.Items.Count; i++)
                {
                    if (cblSize.Items[i].Selected == true)
                    {
                        Int64 SizeID = Convert.ToInt64(cblSize.Items[i].Value);
                        int Quantity = Convert.ToInt32(txtQuantity.Text);

                        // SqlCommand cmd2 = new SqlCommand("insert into tblProductSizeQuantity(PID,SizeID,Quantity) values('" + PID + "','" + SizeID + "','" + Quantity + "')", con);
                        SqlCommand cmd2 = new SqlCommand("INSERT INTO T_ProductSizeQuantity(PID,SizeID,Quantity) VALUES(@PID,@SizeID,@Quantity)", con);
                        cmd2.Parameters.AddWithValue("@PID", Convert.ToInt32(ProdID));
                        cmd2.Parameters.AddWithValue("@SizeID", SizeID);
                        cmd2.Parameters.AddWithValue("@Quantity", Quantity);
                        cmd2.ExecuteNonQuery();
                    }
                }

                //*************************************************************************************
                //Insert and upload images
                if (img01.HasFile)
                {
                    string SavePath = Server.MapPath("~/Images/Produits/") + ProdID;
                    if (!Directory.Exists(SavePath))
                    {
                        Directory.CreateDirectory(SavePath);

                    }
                    string Extention = Path.GetExtension(img01.PostedFile.FileName);
                    img01.SaveAs(SavePath + "\\" + txtProductName.Text.ToString().Trim() + "01" + Extention);
                    SqlCommand cmd3 = new SqlCommand("INSERT INTO T_ProductImages(ProdID,Name,Extention) VALUES(@ProdID,@Name,@Extention)", con);
                    cmd3.Parameters.AddWithValue("@ProdID", Convert.ToInt32(ProdID));
                    cmd3.Parameters.AddWithValue("@Name", txtProductName.Text.ToString().Trim() + "01");
                    cmd3.Parameters.AddWithValue("@Extention", Extention);
                    cmd3.ExecuteNonQuery();
                    MsgLbl.Text = "Product Added Successfully";
                    MsgLbl.ForeColor = System.Drawing.Color.Green;
                }
                //2nd fileupload
                if (img02.HasFile)
                {
                    string SavePath = Server.MapPath("~/Images/Produits/") + ProdID;
                    if (!Directory.Exists(SavePath))
                    {
                        Directory.CreateDirectory(SavePath);

                    }
                    string Extention = Path.GetExtension(img02.PostedFile.FileName);
                    img02.SaveAs(SavePath + "\\" + txtProductName.Text.ToString().Trim() + "02" + Extention);

                    //SqlCommand cmd4 = new SqlCommand("insert into tblProductImages values('" + PID + "','" + txtProductName.Text.ToString().Trim() + "02" + "','" + Extention + "')", con);
                    SqlCommand cmd4 = new SqlCommand("INSERT INTO T_ProductImages(ProdID,Name,Extention) VALUES(@ProdID,@Name,@Extention)", con);
                    cmd4.Parameters.AddWithValue("@ProdID", Convert.ToInt32(ProdID));
                    cmd4.Parameters.AddWithValue("@Name", txtProductName.Text.ToString().Trim() + "02");
                    cmd4.Parameters.AddWithValue("@Extention", Extention);
                    cmd4.ExecuteNonQuery();
                }

                //3rd file upload 
                if (img03.HasFile)
                {
                    string SavePath = Server.MapPath("~/Images/Produits/") + ProdID;
                    if (!Directory.Exists(SavePath))
                    {
                        Directory.CreateDirectory(SavePath);

                    }
                    string Extention = Path.GetExtension(img03.PostedFile.FileName);
                    img03.SaveAs(SavePath + "\\" + txtProductName.Text.ToString().Trim() + "03" + Extention);

                    //SqlCommand cmd5 = new SqlCommand("insert into tblProductImages values('" + PID + "','" + txtProductName.Text.ToString().Trim() + "03" + "','" + Extention + "')", con);
                    SqlCommand cmd5 = new SqlCommand("INSERT INTO T_ProductImages(ProdID,Name,Extention) VALUES(@ProdID,@Name,@Extention)", con);
                    cmd5.Parameters.AddWithValue("@ProdID", Convert.ToInt32(ProdID));
                    cmd5.Parameters.AddWithValue("@Name", txtProductName.Text.ToString().Trim() + "03");
                    cmd5.Parameters.AddWithValue("@Extention", Extention);
                    cmd5.ExecuteNonQuery();
                }
                //4th file upload control
                if (img04.HasFile)
                {
                    string SavePath = Server.MapPath("~/Images/Produits/") + ProdID;
                    if (!Directory.Exists(SavePath))
                    {
                        Directory.CreateDirectory(SavePath);

                    }
                    string Extention = Path.GetExtension(img04.PostedFile.FileName);
                    img04.SaveAs(SavePath + "\\" + txtProductName.Text.ToString().Trim() + "04" + Extention);

                    //SqlCommand cmd6 = new SqlCommand("insert into tblProductImages values('" + PID + "','" + txtProductName.Text.ToString().Trim() + "04" + "','" + Extention + "')", con);
                    SqlCommand cmd6 = new SqlCommand("INSERT INTO T_ProductImages(ProdID,Name,Extention) VALUES(@ProdID,@Name,@Extention)", con);
                    cmd6.Parameters.AddWithValue("@ProdID", Convert.ToInt32(ProdID));
                    cmd6.Parameters.AddWithValue("@Name", txtProductName.Text.ToString().Trim() + "04");
                    cmd6.Parameters.AddWithValue("@Extention", Extention);
                    cmd6.ExecuteNonQuery();
                }

                //5th file upload
                if (img05.HasFile)
                {
                    string SavePath = Server.MapPath("~/Images/Produits/") + ProdID;
                    if (!Directory.Exists(SavePath))
                    {
                        Directory.CreateDirectory(SavePath);

                    }
                    string Extention = Path.GetExtension(img05.PostedFile.FileName);
                    img05.SaveAs(SavePath + "\\" + txtProductName.Text.ToString().Trim() + "05" + Extention);

                   
                    SqlCommand cmd7 = new SqlCommand("INSERT  INTO T_ProductImages(ProdID,Name,Extention) VALUES(@ProdID,@Name,@Extention)", con);
                    cmd7.Parameters.AddWithValue("@ProdID", Convert.ToInt32(ProdID));
                    cmd7.Parameters.AddWithValue("@Name", txtProductName.Text.ToString().Trim() + "05");
                    cmd7.Parameters.AddWithValue("@Extention", Extention);
                    cmd7.ExecuteNonQuery();

                    BindGridview1();
                    Response.Redirect("AddProduits.aspx");
                    MsgLbl.Text = "Product Added Successfully";
                    MsgLbl.ForeColor = System.Drawing.Color.Green;
                    Effacer();
                    con.Close();
                }
                //*************************************************************************************
               
            }

        
    }
        //**************************************************************************************************
        private void Effacer()
        {
            txtProductName.Text = string.Empty;
            txtselPrice.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtDescription.Text = string.Empty;
            txtPDetail.Text = string.Empty;
            txtMatCare.Text = string.Empty;
            txtQuantity.Text = string.Empty;
            addlBrand.ClearSelection();
            addlBrand.Items.FindByValue("0").Selected = true;

            addlCategory.ClearSelection();
            addlCategory.Items.FindByValue("0").Selected = true;

            addlSubCategory.ClearSelection();
            addlSubCategory.Items.FindByValue("0").Selected = true;

            addlGender.ClearSelection();
            addlGender.Items.FindByValue("0").Selected = true;
            chFD.Checked = false;
            ch30Ret.Checked = false;
            cbCOD.Checked = false;
            cblSize.ClearSelection();
            cblSize.Visible = false;
        }


        //**************************************************************************************************
        protected void addlCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            addlSubCategory.Enabled = true;
            int MainCategoryID = Convert.ToInt32(addlCategory.SelectedItem.Value);

            using (SqlConnection con = new SqlConnection(CSdb))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM T_SubCategory WHERE  CatID='" + addlCategory.SelectedItem.Value + "'", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    addlSubCategory.DataSource = dt;
                    addlSubCategory.DataTextField = "SubCatName";
                    addlSubCategory.DataValueField = "SubCatID";
                    addlSubCategory.DataBind();
                    addlSubCategory.Items.Insert(0, new ListItem("-Select-", "0"));

                }
            }
        }

        protected void addlSubCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (addlSubCategory.SelectedIndex != 0)
            {
                addlGender.Enabled = true;
            }
            else
            {
                addlGender.Enabled = false;
            }
        }

        protected void addlGender_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(CSdb))
            {
                if (con.State == ConnectionState.Closed) { con.Open(); }
                // requete parametrée Marequete
                string Marequete = "SELECT * FROM T_Sizes WHERE BrandID=@BrandID AND CatID=@CatID AND SubCatID=@SubCatID AND GenderID=@GenderID ";

                // Marequete = "Select * from tblSizes where BrandID='" + ddlBrand.SelectedValue + "' and CategoryID='" + ddlCategory.SelectedValue + "' and SubCategoryID='" + ddlSubCategory.SelectedValue + "' and GenderID='" + ddlGender.SelectedValue + "'";
                SqlCommand cmd = new SqlCommand(Marequete, con);
                cmd.Parameters.AddWithValue("@BrandID", addlBrand.SelectedValue);
                cmd.Parameters.AddWithValue("@CatID", addlCategory.SelectedValue);
                cmd.Parameters.AddWithValue("@SubCatID", addlSubCategory.SelectedValue);
                cmd.Parameters.AddWithValue("@GenderID", addlGender.SelectedValue);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                con.Close();
                if (dt.Rows.Count != 0)
                {
                    cblSize.DataSource = dt;
                    cblSize.DataTextField = "SizeName";
                    cblSize.DataValueField = "SizeID";
                    cblSize.DataBind();

                }
            }
        }

        //**************************************************************************************************************
      
    }
}