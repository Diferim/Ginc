﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Globalization;
using System.Threading;

namespace EcommerceDiva
{
    public partial class ProductView : System.Web.UI.Page

    {
        public static String CSdb = ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString;
        readonly Int32 myQty = 1;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["ProdID"] != null)
            {
                if (!IsPostBack)
                {
                    divSuccess.Visible = false;
                    BindProductImage2();
                    BindProductDetails();
                    BindCartNumber();
                }
            }
            else
            {
                Response.Redirect("~/Products.aspx");
            }
        }
        //***************************************************************************************************************************
        private void BindProductDetails()
        {
            Int64 ProdID = Convert.ToInt64(Request.QueryString["ProdID"]);
            using (SqlConnection con = new SqlConnection(CSdb))
            {
                SqlCommand cmd = new SqlCommand("PS_BindProductDetails", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@ProdID", ProdID);
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    rptrProductDetails.DataSource = dt;
                    rptrProductDetails.DataBind();
                    Session["CartPID"] = Convert.ToInt32(dt.Rows[0]["ProdID"].ToString());
                    Session["myPName"] = dt.Rows[0]["PName"].ToString();
                    Session["myPPrice"] = dt.Rows[0]["ProdPrice"].ToString();
                    Session["myPSelPrice"] = dt.Rows[0]["ProdSelPrice"].ToString();
                }

            }
        }
        //***************************************************************************************************************************
         private void BindProductImage()
      {
         Int64 ProdID = Convert.ToInt64(Request.QueryString["ProdID"]);
           using (SqlConnection con = new SqlConnection(CSdb))
        {
          using (SqlCommand cmd = new SqlCommand("SELECT * FROM T_ProductImages WHERE ProdID='" + ProdID + "'", con))
         {
        cmd.CommandType = CommandType.Text;
        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
        {
        DataTable dt = new DataTable();
         sda.Fill(dt);
         rptrImage.DataSource = dt;
        rptrImage.DataBind();
          }
       }
         }
        }
        //***************************************************************************************************************************
        private void BindProductImage2()
        {
            Int64 ProdID = Convert.ToInt64(Request.QueryString["ProdID"]);
            using (SqlConnection con = new SqlConnection(CSdb))
            {
                SqlCommand cmd = new SqlCommand("PS_BindProductImages", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@ProdID", ProdID);
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    rptrImage.DataSource = dt;
                    rptrImage.DataBind();
                }
            }
        }
        //***************************************************************************************************************************
        protected string GetActiveImgClass(int ItemIndex)
        {
            if (ItemIndex == 0)
            {
                return "active";
            }
            else
            {
                return "";

            }
        }

        //***************************************************************************************************************************
        protected void rptrProductDetails_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                string BrandID = (e.Item.FindControl("hfBrandID") as HiddenField).Value;
                string CatID = (e.Item.FindControl("hfCatID") as HiddenField).Value;
                string SubCatID = (e.Item.FindControl("hfSubCatID") as HiddenField).Value;
                string GenderID = (e.Item.FindControl("hfGenderID") as HiddenField).Value;

                RadioButtonList rblSize = e.Item.FindControl("rblSize") as RadioButtonList;

                using (SqlConnection con = new SqlConnection(CSdb))
                {
                    using (SqlCommand cmd = new SqlCommand("SELECT * FROM T_Sizes WHERE BrandID='" + BrandID + "' AND CatID=" + CatID + " AND SubCatID=" + SubCatID + " AND GenderID=" + GenderID + "", con))
                    {
                        cmd.CommandType = CommandType.Text;
                        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                        {
                            DataTable dt = new DataTable();
                            sda.Fill(dt);
                            rblSize.DataSource = dt;
                            rblSize.DataTextField = "Sizename";
                            rblSize.DataValueField = "SizeID";
                            rblSize.DataBind();
                        }
                    }
                }
            }
        }

        //***************************************************************************************************************************
        protected void btnAddtoCart_Click(object sender, EventArgs e)
        {
            string SelectedSize = string.Empty;
            foreach (RepeaterItem item in rptrProductDetails.Items)
            {
                if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                {
                    var rbList = item.FindControl("rblSize") as RadioButtonList;
                    SelectedSize = rbList.SelectedValue;
                    var lblError = item.FindControl("lblError") as Label;
                    lblError.Text = "";
                }
            }

            if (SelectedSize != "")
            {
                Int64 ProdID = Convert.ToInt64(Request.QueryString["ProdID"]);
                //if (Request.Cookies["CartPID"] != null)
                //{
                //    string CookiePID = Request.Cookies["CartPID"].Value.Split('=')[1];
                //    CookiePID = CookiePID + "," + PID + "-" + SelectedSize;
                //    HttpCookie CartProducts = new HttpCookie("CartPID");
                //    CartProducts.Values["CartPID"] = CookiePID;
                //    CartProducts.Expires = DateTime.Now.AddDays(30);
                //    Response.Cookies.Add(CartProducts);
                //}
                //else
                //{
                //    HttpCookie CartProducts = new HttpCookie("CartPID");
                //    CartProducts.Values["CartPID"] = PID.ToString() + "-" + SelectedSize;
                //    CartProducts.Expires = DateTime.Now.AddDays(30);
                //    Response.Cookies.Add(CartProducts);
                //}
                AddToCartProduction();
                Response.Redirect("ProductView.aspx?ProdID=" + ProdID);
            }
            else
            {
                foreach (RepeaterItem item in rptrProductDetails.Items)
                {
                    if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                    {
                        var lblError = item.FindControl("lblError") as Label;
                        lblError.Text = "Please select a size";
                    }
                }

            }



        }
        //***************************************************************************************************************************
        protected override void InitializeCulture()
        {
            CultureInfo ci = new CultureInfo("en-IN");
            ci.NumberFormat.CurrencySymbol = "€";
            Thread.CurrentThread.CurrentCulture = ci;

            base.InitializeCulture();
        }

        //***************************************************************************************************************************
        public void BindCartNumber()
        {
            if (Session["USERID"] != null)
            {
                string IdUser = Session["USERID"].ToString();
                DataTable dt = new DataTable();
                using (SqlConnection con = new SqlConnection(CSdb))
                {
                    SqlCommand cmd = new SqlCommand("PS_BindCartNumberz", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.AddWithValue("@IdUser", IdUser);
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            string CartQuantity = dt.Compute("Sum(Qty)", "").ToString();
                            CartBadge.InnerText = CartQuantity;

                        }
                        else
                        {
                            CartBadge.InnerText = 0.ToString();
                        }
                    }
                }
            }
        }

        //***************************************************************************************************************************
        private void AddToCartProduction()
        {
            if (Session["Username"] != null)
            {
                Int32 IdUser= Convert.ToInt32(Session["USERID"].ToString());
                Int64 ProdID = Convert.ToInt64(Request.QueryString["ProdID"]);
                using (SqlConnection con = new SqlConnection(CSdb))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("PS_IsProductExistInCart", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.AddWithValue("@IdUser", IdUser);
                    cmd.Parameters.AddWithValue("@PID", ProdID);
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        if (dt.Rows.Count > 0)
                        {
                            Int32 updateQty = Convert.ToInt32(dt.Rows[0]["Qty"].ToString());
                            SqlCommand myCmd = new SqlCommand("PS_UpdateCart", con)
                            {
                                CommandType = CommandType.StoredProcedure
                            };
                            myCmd.Parameters.AddWithValue("@Quantity", updateQty + 1);
                            myCmd.Parameters.AddWithValue("@CartPID", ProdID);
                            myCmd.Parameters.AddWithValue("@IdUser", IdUser);
                            Int64 CartID = Convert.ToInt64(myCmd.ExecuteScalar());
                            BindCartNumber();
                            divSuccess.Visible = true;
                        }
                        else
                        {
                            SqlCommand myCmd = new SqlCommand("PS_InsertCart", con)
                            {
                                CommandType = CommandType.StoredProcedure
                            };
                            myCmd.Parameters.AddWithValue("@UID", IdUser);
                            myCmd.Parameters.AddWithValue("@PID", Session["CartPID"].ToString());
                            myCmd.Parameters.AddWithValue("@PName", Session["myPName"].ToString());
                            myCmd.Parameters.AddWithValue("@PPrice", Session["myPPrice"].ToString());
                            myCmd.Parameters.AddWithValue("@PSelPrice", Session["myPSelPrice"].ToString());
                            myCmd.Parameters.AddWithValue("@Qty", myQty);
                            Int64 CartID = Convert.ToInt64(myCmd.ExecuteScalar());
                            con.Close();
                            BindCartNumber();
                            divSuccess.Visible = true;
                        }
                    }
                }
            }
            else
            {
                Int64 ProdID = Convert.ToInt64(Request.QueryString["ProdID"]);
                Response.Redirect("Login.aspx?rurl=" + ProdID);
            }
        }
        //***************************************************************************************************************************
        protected void btnCart2_ServerClick(object sender, EventArgs e)
        {
            Response.Redirect("Panier.aspx");
        }
    }
}