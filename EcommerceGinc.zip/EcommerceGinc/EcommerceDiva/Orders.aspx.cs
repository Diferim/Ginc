﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EcommerceDiva
{
    public partial class Orders : System.Web.UI.Page
    {
        public static String CSdb = ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["Username"] != null)
                {
                    bindGrid1();
                    //bindGrid2();
                }
                else
                {
                    Response.Redirect("Login.aspx");
                }
            }

        }

        //================================================

        private void bindGrid1()
        {

            SqlConnection con = new SqlConnection(CSdb);
            string qr = "SELECT * FROM T_Orders ";
            SqlCommand cmd = new SqlCommand(qr, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            con.Close();
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }
}