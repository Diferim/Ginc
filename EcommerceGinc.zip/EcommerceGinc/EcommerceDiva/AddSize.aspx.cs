﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace EcommerceDiva
{
    public partial class AddSize : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (! IsPostBack)
            {
                BindBrand();
                BindMainCategory();
                BindGender();
                BindReapterSize();
            }
        }
        //********************************************************************************************
        private void BindReapterSize()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT A.*,B.*,C.*,D.*,E.* FROM T_Sizes A INNER JOIN  T_Category B on B.CatID =A.CatID  INNER JOIN T_Brands C on C.BrandID =A.BrandID INNER JOIN T_SubCategory D on D.SubCatID =A.SubCatID INNER JOIN T_Gender E on E.GenderID =A.GenderID ORDER BY SizeID DESC ", con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        rptrSize.DataSource = dt;
                        rptrSize.DataBind();
                    }
                }
            }
        }
        //*********************************************************************************************

        private void BindGender()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM T_Gender with(nolock)", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    addlGender.DataSource = dt;
                    addlGender.DataTextField = "GenderName";
                    addlGender.DataValueField = "GenderID";
                    addlGender.DataBind();
                    addlGender.Items.Insert(0, new ListItem("-Select-", "0"));

                }
            }
        }
        //*********************************************************************************************
        private void BindMainCategory()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM T_Category", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    addlCategory.DataSource = dt;
                    addlCategory.DataTextField = "CatName";
                    addlCategory.DataValueField = "CatID";
                    addlCategory.DataBind();
                    addlCategory.Items.Insert(0, new ListItem("-Select-", "0"));

                }
            }
        }
        //***********************************************************************************

        private void BindBrand()
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM T_Brands", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    addlBrand.DataSource = dt;
                    addlBrand.DataTextField = "Name";
                    addlBrand.DataValueField = "BrandID";
                    addlBrand.DataBind();
                    addlBrand.Items.Insert(0, new ListItem("-Select-", "0"));

                }
            }
        }
        //******************************************************************************************************


        protected void BtnAddSize_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO T_Sizes(SizeName,BrandID,CatID,SubCatID,GenderID) VALUES('" + txtSize.Text + "','" +addlBrand.SelectedItem.Value + "','" + addlCategory.SelectedItem.Value + "','" + addlSubCategory.SelectedItem.Value + "','" + addlGender.SelectedItem.Value + "')", con);
                cmd.ExecuteNonQuery();
                MsgLbl.Text = "Gender Added Successfully";
                MsgLbl.ForeColor = System.Drawing.Color.Green;
                //Response.Write("<script> alert('Size Added Successfully ');  </script>");
                txtSize.Text = string.Empty;

                con.Close();
                addlBrand.ClearSelection();
                addlBrand.Items.FindByValue("0").Selected = true;

                addlCategory.ClearSelection();
                addlCategory.Items.FindByValue("0").Selected = true;


                addlSubCategory.ClearSelection();
                addlSubCategory.Items.FindByValue("0").Selected = true;

                addlGender.ClearSelection();
                addlGender.Items.FindByValue("0").Selected = true;

            }
            BindReapterSize();
        }
        protected void addlCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            int MainCategoryID = Convert.ToInt32(addlCategory.SelectedItem.Value);

            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DivanaDB"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM T_SubCategory WHERE  CatID='" + addlCategory.SelectedItem.Value + "'", con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count != 0)
                {
                    addlSubCategory.DataSource = dt;
                    addlSubCategory.DataTextField = "SubCatName";
                    addlSubCategory.DataValueField = "SubCatID";
                    addlSubCategory.DataBind();
                    addlSubCategory.Items.Insert(0, new ListItem("-Select-", "0"));

                }
            }
        }

    }
}