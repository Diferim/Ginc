CREATE DATABASE DivanaDB

USE DivanaDB

create table T_Users
(
IdUser int identity(1,1) primary key not null,
Username nvarchar(100) not Null, 
Password nvarchar(100) not Null,
Email nvarchar(100) not Null,
Name nvarchar(100) not Null,
Usertype nvarchar(50) default 'User'
)
insert into T_Users Values('dinnov','1234','diferim10@gmail.com','Dinnov','Admin')
insert into T_Users Values('diva','1234','diva@yahoo.com','Divana','User')
insert into T_Users Values('vendor','1234','vendor@yahoo.com','Divana','Vendor')

select *  from T_Users


create table T_ForgotPwd
(
Id nvarchar (500)  not null,
IdUser int null,
RequestDateTime DATETIME null,
Constraint [FK_ForgotPwd_T_Users] FOREIGN KEY ([IdUser]) REFERENCES [T_Users] ([IdUser])

)

select *  from T_ForgotPwd



CREATE TABLE T_Cart(
	[CartID] [int] IDENTITY(1,1) NOT NULL,
	[UID] [int] NULL,
	[PID] [int] NULL,
	[PName] [nvarchar](max) NULL,
	[PPrice] [money] NULL,
	[PSelPrice] [money] NULL,
	[SubPAmount]  AS ([PPrice]*[Qty]),
	[SubSAmount]  AS ([PSelPrice]*[Qty]),
	[Qty] [int] NULL,
)



CREATE TABLE T_Brands(
	[BrandID] [int] IDENTITY(1,1) NOT NULL primary key,
	[Name] [nvarchar](500) NOT NULL,
)
select *  from T_Brands
delete   from T_Brands where BrandID=5

drop table T_Brands

CREATE TABLE T_Category(
	[CatID] [int] IDENTITY(1,1) NOT NULL primary key,
	[CatName] [nvarchar](max) NOT NULL,
)
select *  from T_Category

CREATE TABLE T_SubCategory(
	[SubCatID] [int] IDENTITY(1,1) NOT NULL primary key,
	[SubCatName] [nvarchar](max) NOT NULL,
	[CatID] [int] NULL,
CONSTRAINT [FK_T_SubCategory_T_Category] FOREIGN KEY([CatID]) REFERENCES T_Category ([CatID])
)

select *  from T_SubCategory

create table T_Gender
(
GenderID int identity(1,1) primary key,
GenderName   nvarchar(MAX)

)

select *  from T_Gender

create table T_Sizes
(
SizeID int identity(1,1) primary key,
SizeName   nvarchar(500),
BrandID int,
CatID int,
SubCatID int,
GenderID int,
Constraint [FK_T_Sizes_ToBrands] FOREIGN KEY ([BrandID]) REFERENCES [T_Brands] ([BrandID]),
Constraint [FK_T_Sizes_ToCategory] FOREIGN KEY ([CatID]) REFERENCES [T_Category] ([CatID]),
Constraint [FK_T_Sizes_SubCategory] FOREIGN KEY ([SubCatID]) REFERENCES [T_SubCategory] ([SubCatID]),
Constraint [FK_T_Sizes_Gender] FOREIGN KEY ([GenderID]) REFERENCES [T_Gender] ([GenderID])

)

select *  from T_Sizes


CREATE TABLE T_Orders(
	[OrderID] [int] IDENTITY(1,1) NOT NULL primary key,
	[IdUser] [int] NULL,
	[EMail] [nvarchar](max) NULL,
	[CartAmount] [money] NULL,
	[CartDiscount] [money] NULL,
	[TotalPaid] [money] NULL,
	[PaymentType] [nvarchar](50) NULL,
	[PaymentStatus] [nvarchar](50) NULL,
	[DateOfPurchase] [datetime] NULL,
	[Name] [nvarchar](200) NULL,
	[Address] [nvarchar](max) NULL,
	[MobileNumber] [nvarchar](50) NULL,
	[OrderStatus] [nvarchar](50) NULL,
	[OrderNumber] [nvarchar](50) NULL,
	Constraint [FK_TOrders_T_Users] FOREIGN KEY ([IdUser]) REFERENCES [T_Users] ([IdUser])
)

CREATE TABLE T_OrderProducts(
	[OrderProID] [int] IDENTITY(1,1) NOT NULL primary key,
	[OrderID] [nvarchar](50) NULL,
	[IdUser] [int] NULL,
	[ProdID] [int] NULL,
	[Products] [nvarchar](max) NULL,
	[Quantity] [int] NULL,
	[OrderDate] [datetime] NULL,
	[Status] [nvarchar](100) NULL,
Constraint [FK_T_OrderProducts_T_Users] FOREIGN KEY ([IdUser]) REFERENCES [T_Users] ([IdUser])
)


create table T_Products
(
ProdID int identity(1,1) primary key ,
PName   nvarchar(MAX) NOT NULL,
ProdPrice money,
ProdSelPrice money,
ProdDescription nvarchar(MAX) NOT NULL,
ProdProductDetails nvarchar(MAX),
ProdMaterialCare  nvarchar(MAX),
FreeDelivery int,
[30DayRet]  int,
COD       int,
BrandID int,
CatID int,
SubCatID int,
GenderID int,
Constraint [FK_T_Products_T_Brands] FOREIGN KEY ([BrandID]) REFERENCES [T_Brands] ([BrandID]),
Constraint [FK_T_Products_T_Category] FOREIGN KEY ([CatID]) REFERENCES [T_Category] ([CatID]),
Constraint [FK_T_Products_T_SubCategory] FOREIGN KEY ([SubCatID]) REFERENCES [T_SubCategory] ([SubCatID]),
Constraint [FK_T_Products_T_Gender] FOREIGN KEY ([GenderID]) REFERENCES [T_Gender] ([GenderID])


)

select * from T_Products
select * from T_Gender
select * from T_ProductImages
select * from T_Cart
select * from T_ProductSizeQuantity
select * from T_Cart
select * from T_Purchase
select * from T_Orders
select * from T_Sizes
select * from T_OrderProducts

PS_ShowAllProducts


delete from T_Purchase
delete from T_Gender
delete from T_OrderProducts
delete from T_Orders
delete from T_Cart
delete from T_Category
delete from T_SubCategory
delete from T_Brands
delete from T_Sizes
delete from T_Products
delete from T_ProductSizeQuantity
delete from T_ProductImages

CREATE TABLE T_ProductImages(
	[PIMGID] [int] IDENTITY(1,1) NOT NULL,
	[ProdID] [int] NULL,
	[Name] [nvarchar](max) NOT NULL,
	[Extention] [nvarchar](500) NULL,
	Constraint [FK_T_ProductImages_T_Products] FOREIGN KEY ([ProdID]) REFERENCES [T_Products] ([ProdID])
	)
	
	select * from T_ProductImages

create table T_ProductSizeQuantity
(
ProdSizeQuantID int identity(1,1) primary key,
PID int,
SizeID int,
Quantity int,
Constraint [FK_T_ProductSizeQuantity_T_Products] FOREIGN KEY ([PID]) REFERENCES [T_Products] ([ProdID]),
Constraint [FK_T_ProductSizeQuantity_T_Sizes] FOREIGN KEY ([SizeID]) REFERENCES [T_Sizes] ([SizeID])
)

select * from T_ProductSizeQuantity

-----14
create table T_Purchase
(
PurchaseID int identity(1,1) primary key,
IdUser int,
PIDSizeID nvarchar(MAX),
CartAmount money,
CartDiscount money,
TotalPayed money,
PaymentType nvarchar(50),
PaymentStatus nvarchar(50),
DateOfPurchase datetime,
Name nvarchar(200),
Address nvarchar(MAX),
PinCode nvarchar(10),
MobileNumber nvarchar(50),
CONSTRAINT [FK_T_Purchase_T_Users] FOREIGN KEY ([IdUser]) REFERENCES [T_Users]([IdUser])

)




--------------------------  Procedures Stock�es PS ----------------
CREATE PROCEDURE PS_ShowAllProducts
AS
SELECT DISTINCT  t1.ProdID,t1.PName,t1.ProdPrice,t1.ProdSelPrice,t2.Name AS Brand,
t3.CatName,t4.SubCatName, t5.GenderName AS Gender,
t6.SizeName,t8.Quantity FROM T_Products AS t1  INNER JOIN 
T_Brands AS t2 on t2.BrandID=t1.BrandID  INNER JOIN 
T_Category AS t3 ON t3.CatID=t1.CatID  INNER JOIN 
T_SubCategory AS t4 ON t4.SubCatID=t1.SubCatID  INNER JOIN 
T_Gender AS t5 ON t5.GenderID =t1.GenderID  INNER JOIN 
T_Sizes AS t6 ON t6.SubCatID=t1.SubCatID  INNER JOIN 
T_ProductSizeQuantity AS t8 ON t8.PID=t1.ProdID ORDER BY t1.PName


-----------------------------------------------------------
CREATE PROCEDURE PS_BindGridSize
AS
select t1.SizeID,t1.SizeName,t2.Name as Brand,
t3.CatName as Category,t4.SubCatName as SubCategory,
t5.GenderName as Gender from T_Sizes as t1 with(nolock) inner join 
T_Brands as t2 with(nolock) on t2.BrandID=t1.BrandID inner join 
T_Category as t3 with(nolock) on t3.CatID=t1.CatID inner join T_SubCategory as t4 with(nolock) on 
t4.SubCatID=t1.SubCatID inner join 
T_Gender as t5 with(nolock) on t5.GenderID=t1.GenderID

----------------------------------------------------------
CREATE PROCEDURE PS_UpdateSize
(
@SizeID int,
@SizeName nvarchar(MAX),
@BrandID int,
@CatID int,
@SubCatID int,
@GenderID int
)
AS
UPDATE T_Sizes SET SizeName=@SizeName,
BrandID=@BrandID,
CatID=@CatID,
SubCatID=@SubCatID,
GenderID=@GenderID WHERE SizeID=@SizeID

-----------------------------------------------------------

---1
Create procedure PS_InsertProducts
(
@PName nvarchar(MAX),
@ProdPrice money,
@ProdSelPrice money,
@ProdDescription nvarchar(MAX),
@ProdProductDetails nvarchar(MAX),
@ProdMaterialCare nvarchar(MAX),
@FreeDelivery int,
@30DayRet int,
@COD int,
@BrandID int,
@CatID int,
@SubCatID int,
@GenderID int
)
AS

insert into T_Products values(@PName,@ProdPrice,@ProdSelPrice,@ProdDescription,@ProdProductDetails,@ProdMaterialCare,@FreeDelivery,
@30DayRet,@COD,@BrandID,@CatID,@SubCatID,@GenderID) 
select SCOPE_IDENTITY()
Return 0


---2
create procedure PS_BindAllProducts
AS
select A.*,B.*,C.Name ,A.ProdPrice-A.ProdSelPrice as DiscAmount,B.Name as ImageName, 
C.Name as BrandName from T_Products A
inner join T_Brands C on C.BrandID =A.BrandID
cross apply(
select top 1 * from T_ProductImages B where B.ProdID= A.ProdID order by B.ProdID desc
)B
order by A.ProdID desc

Return 0

---------3
create function GetSizeName
   
   (
   @SizeID int
   )
   RETURNS Nvarchar(10)
   as
   Begin
   Declare @SizeName nvarchar(10)
 select @SizeName=SizeName from T_Sizes where SizeID=@SizeID
 
   RETURN @SizeName
   
   End
   
   
   ---4
   
   CREATE PROCEDURE PS_BindAllProducts2
AS
SELECT A.*, B.*,C.Name, A.ProdPrice-A.ProdSelPrice AS DiscAmount, B.Name AS ImageName, C.Name AS BrandName FROM T_Products A
INNER JOIN T_Brands C ON C.BrandID = A.BrandID
CROSS APPLY(
SELECT TOP 1 * FROM T_ProductImages B WHERE B.ProdID = A.ProdID ORDER BY B.ProdID DESC
)B
ORDER BY A.ProdID DESC

---5

create PROCEDURE PS_BindCartNumberz
(
@IdUser int
)
AS
SELECT * FROM T_Cart D CROSS APPLY ( SELECT TOP 1 E.Name,Extention FROM T_ProductImages E WHERE E.ProdID = D.PID) Name where D.UID = @IdUser

---6

-----------------------------------
CREATE PROCEDURE PS_ReportSell

AS 
select t1.OrderID,t3.Name,t2.PName AS ProductName,
       t1.Quantity as SellQty,
	   t4.Quantity as InitialQty,
	   t4.Quantity-t1.Quantity as Available  
	   from T_OrderProducts as t1 inner join T_Products 
	   as t2 on t2.ProdID=t1.ProdID inner join T_Users 
	   as t3 on t3.IdUser=t1.IdUser inner join T_ProductSizeQuantity 
	   as t4 on t4.PID=t1.ProdID
-------------------------------------
CREATE PROCEDURE PS_ReportQtyStart

AS 
select  distinct t2.PName AS ProductName,
t1.Quantity from T_ProductSizeQuantity AS 
t1 inner join T_Products as t2 on t2.ProdID=t1.PID
----------------------------------

create PROCEDURE PS_BindCartProducts
(
@UID int
)
AS
SELECT PID FROM T_Cart WHERE UID = @UID

---7
CREATE PROCEDURE PS_BindPriceData
(
@IdUser int
)
AS
SELECT * FROM T_Cart D CROSS APPLY ( SELECT TOP 1 E.Name,Extention FROM T_ProductImages E WHERE E.ProdID = D.PID) Name where D.UID = @IdUser

---8

CREATE PROCEDURE PS_BindProductDetails
(
@ProdID int
)
AS
SELECT * FROM T_Products where ProdID = @ProdID


create procedure PS_BindProductDetails0
(
@ProdID int
)
AS
select A.*,B.*,C.Name ,A.ProdPrice-A.ProdSelPrice as DiscAmount,B.Name as ImageName, C.Name as BrandName from T_Products A
inner join T_Brands C on C.BrandID =A.BrandID
cross apply(
select top 1 * from T_ProductImages B where B.ProdID= A.ProdID order by B.ProdID desc
)B
order by A.ProdID desc




---9

create PROCEDURE PS_BindProductImages
(
@ProdID int
)
AS
SELECT * FROM T_ProductImages where ProdID = @ProdID

---10
create PROCEDURE PS_BindUserCart
(
@IdUser int
)
AS
SELECT * FROM T_Cart D CROSS APPLY ( SELECT TOP 1 E.Name,Extention FROM T_ProductImages E WHERE E.ProdID = D.PID) Name WHERE D.UID = @IdUser

---11
CREATE PROCEDURE PS_DeleteThisCartItem
@CartID int
AS
BEGIN
DELETE FROM T_Cart WHERE CartID = @CartID
END

--PS_DeleteThisProduct
CREATE PROCEDURE PS_DeleteThisBrand
@BrandID int
AS
BEGIN
DELETE FROM T_Brands WHERE BrandID = @BrandID
END

---12
CREATE PROCEDURE PS_EmptyCart
@IdUser int
AS
BEGIN
DELETE FROM T_Cart WHERE UID = @IdUser
END

---13

CREATE PROCEDURE PS_FindOrderNumber @FindOrderNumber nvarchar(100)
AS
SELECT * FROM T_Orders WHERE OrderNumber = @FindOrderNumber

---14

CREATE PROCEDURE PS_GetUserCartItem
(
@PID int,
@IdUser int
)
AS
SELECT * FROM T_Cart WHERE PID = @PID AND UID = @IdUser

---15

CREATE PROCEDURE PS_InsertCart
(
@UID int,
@PID int,
@PName nvarchar(MAX),
@PPrice money,
@PSelPrice money,
@Qty int
)
AS
INSERT INTO T_Cart VALUES(@UID,@PID,@PName,@PPrice,@PSelPrice,@Qty)
SELECT SCOPE_IDENTITY()

---16

CREATE PROCEDURE PS_InsertOrder
(
@IdUser int,
@Email nvarchar(MAX),
@CartAmount money,
@CartDiscount money,
@TotalPaid money,
@PaymentType nvarchar(50),
@PaymentStatus nvarchar(50),
@DateOfPurchase datetime,
@Name nvarchar(200),
@Address nvarchar(MAX),
@MobileNumber nvarchar(50),
@OrderStatus nvarchar(50),
@OrderNumber nvarchar(50)
)
AS
INSERT INTO T_Orders VALUES(@IdUser,@Email,@CartAmount,@CartDiscount,@TotalPaid,@PaymentType,@PaymentStatus,@DateOfPurchase,@Name,@Address,@MobileNumber,@OrderStatus,@OrderNumber)
SELECT SCOPE_IDENTITY()


---17

CREATE PROCEDURE PS_InsertOrderProducts
(
@OrderID nvarchar(50),
@IdUser int,
@PID int,
@Products nvarchar(MAX),
@Quantity int,
@OrderDate datetime,
@Status nvarchar(100)
)
AS
INSERT INTO T_OrderProducts VALUES (@OrderID,@IdUser,@PID,@Products,@Quantity,@OrderDate,@Status)
SELECT SCOPE_IDENTITY()


----18

CREATE PROCEDURE PS_IsProductExistInCart
(
@PID int,
@IdUser int
)
AS
SELECT * FROM T_Cart where PID = @PID and UID = @IdUser


----19

CREATE PROCEDURE PS_UpdateCart
(
@IdUser int,
@CartPID int,
@Quantity int
)
AS
BEGIN
SET NOCOUNT ON;
UPDATE T_Cart SET Qty = @Quantity WHERE PID = @CartPID AND UID = @IdUser
END

go
-----------------------

------------
create procedure [dbo].[procBindAllProducts2]
AS
select A.*,B.*,C.Name ,A.ProdPrice-A.ProdSelPrice as DiscAmount,B.Name as ImageName, C.Name as BrandName 
from T_Products A
inner join T_Brands C on C.BrandID =A.BrandID
inner join T_Category as t2 on t2.CatID=A.CatID
cross apply(
select top 1 * from T_ProductImages B where B.ProdID= A.ProdID order by B.ProdID desc
)B where t2.CatName='Shirt' 
order by A.ProdID desc

Return 0

---------------

create procedure [dbo].[procBindAllProductsWomanTop]
AS
select A.*,B.*,C.Name ,A.ProdPrice-A.ProdSelPrice as DiscAmount,B.Name as ImageName, C.Name as BrandName 
from T_Products A
inner join T_Brands C on C.BrandID =A.BrandID
inner join T_Category as t2 on t2.CatID=A.CatID
cross apply(
select top 1 * from T_ProductImages B where B.ProdID= A.ProdID order by B.ProdID desc
)B where t2.CatName='Top'
order by A.ProdID desc

Return 0


---------------------------------





-------------------------

create procedure [dbo].[procBindAllProducts3]
AS
select A.*,B.*,C.Name ,A.PPrice-A.PSelPrice as DiscAmount,B.Name as ImageName, C.Name as BrandName 
from tblProducts A
inner join tblBrands C on C.BrandID =A.PBrandID
inner join tblCategory as t2 on t2.CatID=A.PCategoryID
cross apply(
select top 1 * from tblProductImages B where B.PID= A.PID order by B.PID desc
)B where t2.CatName='Pants' or t2.CatName='Jeans'
order by A.PID desc

Return 0

------

create procedure [dbo].[procBindAllProducts4]
AS
select A.*,B.*,C.Name ,A.PPrice-A.PSelPrice as DiscAmount,B.Name as ImageName, C.Name as BrandName 
from tblProducts A
inner join tblBrands C on C.BrandID =A.PBrandID
inner join tblCategory as t2 on t2.CatID=A.PCategoryID
cross apply(
select top 1 * from tblProductImages B where B.PID= A.PID order by B.PID desc
)B where t2.CatName='Jeans' or t2.CatName='Denim Jeans'or t2.CatName='Pants'
order by A.PID desc

Return 0

-------------

create procedure [dbo].[procBindAllProducts4]
AS
select A.*,B.*,C.Name ,A.PPrice-A.PSelPrice as DiscAmount,B.Name as ImageName, C.Name as BrandName 
from tblProducts A
inner join tblBrands C on C.BrandID =A.PBrandID
inner join tblCategory as t2 on t2.CatID=A.PCategoryID
cross apply(
select top 1 * from tblProductImages B where B.PID= A.PID order by B.PID desc
)B where t2.CatName='Jeans' 
order by A.PID desc

Return 0

-----------------

create procedure [dbo].[procBindAllProducts5]
AS
select A.*,B.*,C.Name ,A.PPrice-A.PSelPrice as DiscAmount,B.Name as ImageName, C.Name as BrandName 
from tblProducts A
inner join tblBrands C on C.BrandID =A.PBrandID
inner join tblCategory as t2 on t2.CatID=A.PCategoryID
cross apply(
select top 1 * from tblProductImages B where B.PID= A.PID order by B.PID desc
)B where t2.CatName='Leggings' or t2.CatName='Leggings Western Wear'
order by A.PID desc

Return 0

-------------

create procedure [dbo].[procBindAllProducts6]
AS
select A.*,B.*,C.Name ,A.PPrice-A.PSelPrice as DiscAmount,B.Name as ImageName, C.Name as BrandName 
from tblProducts A
inner join tblBrands C on C.BrandID =A.PBrandID
inner join tblCategory as t2 on t2.CatID=A.PCategoryID
cross apply(
select top 1 * from tblProductImages B where B.PID= A.PID order by B.PID desc
)B where t2.CatName='SAREES' 
order by A.PID desc

Return 0

----------------------